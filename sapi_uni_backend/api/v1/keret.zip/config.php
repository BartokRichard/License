<?php
    $db_host = 'localhost';
    $db_user = 'sapi_uni';
    $db_pass = 'sapi_uni';
    $db_name = 'sapi_uni';
?>