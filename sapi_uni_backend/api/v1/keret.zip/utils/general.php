<?php

function StopWith404() {
    header("HTTP/1.0 404 Not Found");
    die();
}

?>