<?php

    // TODO: kivenni
    $_SESSION['id'] = 1;

    $uid = $_SESSION['id'];

    $sql = "SELECT * FROM `users` WHERE `id`='$uid';";
    $rs = $db->query($sql);
    if($rs->num_rows === 0) {
        die('hiba van ...');
    }

    $row = $rs->fetch_assoc();

    $res = array();
    $res['name'] = $row['name'];
    $res['email'] = $row['email'];

    die( json_encode($res) );

?>