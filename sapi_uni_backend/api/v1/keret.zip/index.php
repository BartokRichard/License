<?php

    require_once 'config.php';
    require_once 'db/db.php';
    require_once 'utils/general.php';

    
    if (!isset($_REQUEST['q']))
        die;

    $request = $_REQUEST['q'];

    $request = rtrim($request, '/');

    /*$splitedpath = explode('/', $request);

    $action = $splitedpath[0];
/* 
    profile, 
    login, 
    register, 
    courses, 
    modules,
    teachers, 
    students, 
    adm
 */

 $routes = array(
    'profile' => 'actions/profile.php',
    'student/courses' => 'actions/student_courses.php',
    'teachers/courses' => 'actions/teachers_courses.php',
 );

    for ($i = 0; $i < count($routes); $i++) {
        if(str_starts_with($request, $routes[$i])) {
            $file = $routes[$i];
            require_once($file);
            die();
        }
    }

    switch (true) {

        case str_starts_with($request, 'profile'):
            require_once('actions/profile.php');
            break;

        case str_starts_with($request, 'student/courses'):
            break;
        
        case str_starts_with($request, 'teacher/courses'):
            break;
        
        default:
            StopWith404();

    }

    /*

    switch ($action) {
        case 'profile':
            require_once 'actions/profile.php'; 
            break;
        case 'student':
            case 'modules':
                require_once 'actions/modules.php'; 
                break;
            case 'courses';
                require_once 'actions/courses.php';
        default:
            echo'Baj van';
            break;
    } */

    // var_dump($action);

    // echo '<pre>'.print_r($splitedpath, true).'</pre>'
?>